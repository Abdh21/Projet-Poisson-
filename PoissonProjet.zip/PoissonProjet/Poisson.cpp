#include <cstdio>
#include <cstdlib>
#include <iostream>

#include <GL/freeglut.h>
#include <jpeglib.h>

#define _USE_MATH_DEFINES
#include <cmath>

int largimg, hautimg;
char presse;
int anglex,angley,x,y,xold,yold;

float angleQueue=0.0, angleNageoire=0;
float ajoutAuto=0.7, ajoutAutoTouche=0.3;

void affichage();
void clavier(unsigned char touche,int x,int y);
void clavierSpec(int touche,int x,int y);
void reshape(int x,int y);
void idle();
void souris(int bouton,int etat,int x,int y);
void sourismouv(int x,int y);

float phi = 0.0f;    // Angle horizontal (autour de l'objet)
float theta = 0.0f;   // Angle vertical (de haut en bas)
float radius = 5.0f;  // Rayon de l'orbite de la caméra
float height = 2.0f;  // Hauteur de la caméra

GLuint textureCorpsPoisson, textureNageoireDorsale, textureNageoireAnale, textureOeilPoisson; // Texture

// Prototypes des fonctions
void init();
void initLumieres();
void initTexturesPoisson();
void dessinerPoissonClown();
void animAuto();
void animTouche();

/*
void loadJpegImage(char *fichier) {
    // Structures pour gérer la décompression JPEG
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *image;
    unsigned char *ligne;

    // Initialiser les structures JPEG
    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);

    // Ouvrir le fichier JPEG
    #ifdef __WIN32
    if (fopen_s(&fichierImage, fichier, "rb") != 0) {
        fprintf(stderr, "Erreur : impossible d'ouvrir le fichier %s\n", fichier);
        exit(EXIT_FAILURE);
    }
    #elif __GNUC__
    if ((image = fopen(fichier, "rb")) == NULL) {
        fprintf(stderr, "Erreur : impossible d'ouvrir le fichier %s\n", fichier);
        exit(EXIT_FAILURE);
    }
    #endif

    // Lire les données du fichier
    jpeg_stdio_src(&cinfo, image);
    jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);

    // Récupérer les dimensions de l'image
    largimg = cinfo.output_width;
    hautimg = cinfo.output_height;

    // Allouer de la mémoire pour stocker les données de l'image
    if (image == NULL) {
        fprintf(stderr, "Erreur : mémoire insuffisante pour charger l'image\n");
        fclose(image);
        exit(EXIT_FAILURE);
    }

    // Lire l'image ligne par ligne
    while (cinfo.output_scanline < cinfo.output_height) {
        ligne = image + (cinfo.output_scanline) * (largimg) * cinfo.output_components;
        jpeg_read_scanlines(&cinfo, &ligne, 1);
    }

    // Terminer la décompression
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(image);
}

void initTexturesCorpsPoisson() {
    loadJpegImage("Corps_texture.jpeg");
    glGenTextures(1, &textureCorpsPoisson);
    glBindTexture(GL_TEXTURE_2D, textureCorpsPoisson);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, largimg, hautimg, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    free(image);
}

void initTextureNageoireDorsale(){

    if (image==NULL){
        fprintf(stderr, "Erreur lors du chargement de l'image\n");
        exit(EXIT_FAILURE);
    }

    glGenTextures(1, &textureNageoireDorsale);
    glBindTexture(GL_TEXTURE_2D, textureNageoireDorsale);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, largimg, hautimg, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    free(image);
}*/

void dessinerNageoire(float largeur, float hauteur, int subdivisions, float positionZ, float echelle) {
    if (subdivisions <= 0 || largeur <= 0 || hauteur <= 0) {
        std::cerr << "Erreur : Les paramètres doivent être strictement positifs." << std::endl;
        return;
    }

    if (subdivisions < 2) subdivisions = 2; // Assurer une subdivision minimale

    float du = 1.0f / subdivisions;
    float dv = 1.0f / subdivisions;

    // Appliquer la transformation (position et échelle)
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, positionZ);  // Positionner la nageoire en fonction du Z
    glScalef(echelle, echelle, 1.0f);  // Réduire l'échelle pour la nageoire secondaire si nécessaire

    // Dessiner les triangles pour la nageoire dorsale
    for (int i = 0; i < subdivisions; i++) {
        for (int j = 0; j < subdivisions; j++) {
            float u = i * du;
            float v = j * dv;
            float u1 = (i + 1) * du;
            float v1 = (j + 1) * dv;

            float sinU = std::sin(M_PI * u);  // Courbure sinusoïdale
            float sinU1 = std::sin(M_PI * u1);
            float absV = std::fabs(v - 0.5f);
            float absV1 = std::fabs(v1 - 0.5f);

            // Positionner les sommets
            float x = largeur * (u - 0.5f);
            float y = hauteur * sinU * (0.5f - absV);
            float z = 0.0f;

            float x1 = largeur * (u1 - 0.5f);
            float y1 = hauteur * sinU1 * (0.5f - absV);
            float y1v = hauteur * sinU * (0.5f - absV1);
            float y1uv = hauteur * sinU1 * (0.5f - absV1);

            glBegin(GL_TRIANGLES);
            // Premier triangle
            glTexCoord2f(u, v);
            glVertex3f(x, y, z);

            glTexCoord2f(u1, v);
            glVertex3f(x1, y1, z);

            glTexCoord2f(u, v1);
            glVertex3f(x, y1v, z);

            // Deuxième triangle
            glTexCoord2f(u1, v);
            glVertex3f(x1, y1, z);

            glTexCoord2f(u1, v1);
            glVertex3f(x1, y1uv, z);

            glTexCoord2f(u, v1);
            glVertex3f(x, y1v, z);
            glEnd();
        }
    }

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);  // Désactiver la texture après utilisation
}

// Fonction principale qui dessine les deux nageoires dorsales
void dessinerNageoireDorsaleDouble(float largeur, float hauteur, int subdivisions) {
    glPushMatrix();
    glTranslatef(-0.05, -0.04, -0.1);
    // Dessiner la première nageoire dorsale (grande, normale)
    dessinerNageoire(largeur, hauteur, subdivisions, 0.4, 1.0);

    glTranslatef(0.15, -0.18, 0.5);
    glRotatef(-10,0.0,0.0,1.0);
    // Dessiner la deuxième nageoire dorsale (plus petite et positionnée plus en arrière)
    dessinerNageoire(largeur, hauteur, subdivisions, -0.1, 1.3);  // Moitié de la taille
    glRotatef(-10,0.0,0.0,1.0);
    glPopMatrix();
}

void dessinerNageoireAnale(float largeur, float hauteur, int subdivisions, float positionZ, float echelle) {
    if (subdivisions <= 0 || largeur <= 0 || hauteur <= 0) {
        std::cerr << "Erreur : Les paramètres doivent être strictement positifs." << std::endl;
        return;
    }

    if (subdivisions < 2) subdivisions = 2; // Assurer une subdivision minimale

    float du = 1.0f / subdivisions;
    float dv = 1.0f / subdivisions;

    glEnable(GL_TEXTURE_2D);  // Activer la texture

    // Appliquer la transformation (position et échelle)
    glPushMatrix();

    for (int i = 0; i < subdivisions; i++) {
        for (int j = 0; j < subdivisions; j++) {
            float u = i * du;
            float v = j * dv;
            float u1 = (i + 1) * du;
            float v1 = (j + 1) * dv;

            float sinU = std::sin(M_PI * u);  // Courbure sinusoïdale
            float sinU1 = std::sin(M_PI * u1);
            float absV = std::fabs(v - 0.5f);
            float absV1 = std::fabs(v1 - 0.5f);

            // Positionner les sommets
            float x = largeur * (u - 0.5f);
            float y = hauteur * sinU * (0.5f - absV);
            float z = 0.0f;

            float x1 = largeur * (u1 - 0.5f);
            float y1 = hauteur * sinU1 * (0.5f - absV);
            float y1v = hauteur * sinU * (0.5f - absV1);
            float y1uv = hauteur * sinU1 * (0.5f - absV1);

            glBegin(GL_TRIANGLES);
            // Premier triangle
            glTexCoord2f(u, v);
            glVertex3f(x, y, z);

            glTexCoord2f(u1, v);
            glVertex3f(x1, y1, z);

            glTexCoord2f(u, v1);
            glVertex3f(x, y1v, z);

            // Deuxième triangle
            glTexCoord2f(u1, v);
            glVertex3f(x1, y1, z);

            glTexCoord2f(u1, v1);
            glVertex3f(x1, y1uv, z);

            glTexCoord2f(u, v1);
            glVertex3f(x, y1v, z);
            glEnd();
        }
    }

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);  // Désactiver la texture après utilisation
}

void dessinerQueue(){
    glPushMatrix();
        glBegin(GL_POLYGON);
        glVertex3f(1.0, 0.2, 0.0);
        glVertex3f(1.6, 0.4, 0.0);
        glVertex3f(1.6, -0.4, 0.0);
        glVertex3f(1.0, -0.2, 0.0);
        glEnd();

        glTranslatef(1.6, 0.0, 0.0);  // Positionner la queue un peu derrière le poisson
        glRotatef(-90, 0.0, 0.0, 1.0);  // Rotation pour l'orientation (a ajuster pour l'animation)
        dessinerNageoire(0.8, 0.6, 6, 0.0, 1.0);   // Appel à la fonction pour dessiner la queue
    glPopMatrix();
}

// Fonction pour dessiner Nemo avec la nageoire anale
void dessinerPoissonClown() {

    // Dessin du corps
    glPushMatrix();
    glEnable(GL_TEXTURE_2D);  // Activer la texture 2D
    glBindTexture(GL_TEXTURE_2D, textureCorpsPoisson);  // Lier la texture du corps du poisson
    glScalef(1.3, 0.6, 0.5);  // Aplatissement du corps pour simuler la forme arrondie
    glColor3f(1.0, 0.65, 0.2);  // Couleur du corps (jaune pour l'exemple)
    glutSolidSphere(1.0, 20, 20);  // Dessiner le corps du poisson (sphère)
    glPopMatrix();

    // Dessiner la nageoire dorsale
    glPushMatrix();
    glRotatef(angleNageoire,1.0,0.0,0.0);
    glTranslatef(0.0, 0.5, -1.2);  // Positionnement de la nageoire dorsale
    glColor3f(1.0, 1.0, 1.0);  // Couleur de la nageoire dorsale
    glScalef(4.0, 1.0, 4.0);  // Taille de la nageoire dorsale
    dessinerNageoireDorsaleDouble(0.3, 0.7, 10);  // Appel de la fonction pour dessiner la nageoire dorsale
    glPopMatrix();

    // Dessin des yeux
    glPushMatrix();
    glColor3f(0.0, 0.0, 0.0);
    glTranslatef(-0.9, 0.2, 0.3);
    glutSolidSphere(0.1, 10, 10);  // Oeil gauche
    glTranslatef(0.0, 0.0, -0.6);
    glutSolidSphere(0.1, 10, 10);  // Oeil droit
    glPopMatrix();

    // Dessiner la nageoire anale
    glPushMatrix();
    glColor3f(1.0, 1.0, 1.0);
    glRotatef(-angleNageoire,1.0,0.0,0.0);
    glTranslatef(0.3, -0.5, 0.0);  // Positionnement de la nageoire anale sous le poisson
    glRotatef(180, 1.0, 0.0, 0.0);  // Rotation pour orienter la nageoire anale (face vers le bas)
    glScalef(1.0, 0.4, 1.0);  // Taille et échelle de la nageoire anale (plus petite)
    glRotatef(-10,0.0,0.0,1.0);
    dessinerNageoireAnale(1.0, 1.0, 6, 1.0, 1.0);  // Appel à la fonction pour dessiner la nageoire anale
    glPopMatrix();

    // Dessiner la queue
    glPushMatrix();
    glRotatef(angleQueue, 0.0, 1.0, 0.0);
    dessinerQueue();
    glPopMatrix();

    // Dessiner les nageoires
    glPushMatrix();
    glScalef(0.7,0.7,1.0);
    glRotatef(-20,0.0, 1.0, 0.0);
    glTranslatef(-1.8, -0.1, 0.70);
    dessinerQueue();
    glRotatef(40,0.0, 1.0, 0.0);
    glTranslatef(0.0, 0.0, -0.1);
    dessinerQueue();
    glPopMatrix();

    glDisable(GL_TEXTURE_2D);  // Désactiver la texture 2D

}

void dessinerAxes() {
    // Axe X (rouge)
    glColor3f(1.0, 0.0, 0.0);  // Rouge
    glBegin(GL_LINES);
        glVertex3f(-10.0, 0.0, 0.0);  // Point de départ de l'axe X
        glVertex3f(10.0, 0.0, 0.0);   // Point d'arrivée de l'axe X
    glEnd();

    // Axe Y (vert)
    glColor3f(0.0, 1.0, 0.0);  // Vert
    glBegin(GL_LINES);
        glVertex3f(0.0, -10.0, 0.0);  // Point de départ de l'axe Y
        glVertex3f(0.0, 10.0, 0.0);   // Point d'arrivée de l'axe Y
    glEnd();

    // Axe Z (bleu)
    glColor3f(0.0, 0.0, 1.0);  // Bleu
    glBegin(GL_LINES);
        glVertex3f(0.0, 0.0, -10.0);  // Point de départ de l'axe Z
        glVertex3f(0.0, 0.0f, 10.0);   // Point d'arrivée de l'axe Z
    glEnd();
}

// COnfigurer les lumieres
void initLumieres() {
    GLfloat direction[] = { 0.0f, -1.0f, 0.0f, 0.0f }; // Lumière directionnelle du haut
    GLfloat intensiteLumiere1[] = { 0.8f, 0.8f, 0.8f, 1.0f }; // Lumière blanche directionnelle
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, direction);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, intensiteLumiere1);

    GLfloat position[] = { 0.0f, 0.0f, 1.0f, 1.0f }; // Lumière ponctuelle
    GLfloat intensiteLumiere2[] = { 0.6f, 0.6f, 0.8f, 1.0f }; // Lumière bleu clair
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_POSITION, position);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, intensiteLumiere2);

    GLfloat ambientLight[] = { 0.2f, 0.2f, 0.2f, 1.0f }; // Lumière ambiante faible
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);

    GLfloat globalAmbient[] = { 0.1f, 0.1f, 0.1f, 1.0f }; // Lumière ambiante globale
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globalAmbient);
}

// Fonction `init` pour initialiser OpenGL
void init() {
    glEnable(GL_DEPTH_TEST);  // Activer le test de profondeur
    glClearColor(0.0, 0.0, 0.0, 1.0);  // Fond noir

    // Initialisation de la projection
    glMatrixMode(GL_PROJECTION);  // Mode de projection
    glLoadIdentity();  // Réinitialiser la matrice de projection
    gluPerspective(45.0, 1.0, 0.1, 100.0);  // Projection perspective (angle de 45°, aspect ratio 1.0, proche à 0.1, éloigné à 100.0)

    glMatrixMode(GL_MODELVIEW);  // Retour au mode modèle-vue
}

void afficher() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Effacer les tampons
    glLoadIdentity(); // Réinitialiser la matrice modèle-vue

    // Calcul de la position de la caméra
    float eyeX = radius * sin(phi) * cos(theta);  // Calculer X
    float eyeY = radius * sin(theta);             // Calculer Y (hauteur)
    float eyeZ = radius * cos(phi) * cos(theta);  // Calculer Z

    // Définir la vue avec gluLookAt
    gluLookAt(eyeX, eyeY, eyeZ,  // Position de la caméra
              0.0f, 0.0f, 0.0f,  // Cible au centre de l'objet
              0.0f, 1.0f, 0.0f); // "Up" vers l'axe Y positif

    dessinerPoissonClown();
    glFlush();

    glutSwapBuffers(); // Échanger les tampons
}

// Fonction principale
int main(int argc, char** argv) {
    glutInit(&argc, argv); // Initialiser GLUT
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH); // Mode d'affichage
    glutInitWindowSize(800, 600); // Taille de la fenêtre
    glutCreateWindow("Test OpenGL"); // Créer la fenêtre

    init(); // Initialiser OpenGL
    initLumieres();
    dessinerPoissonClown();

    glutKeyboardFunc(clavier);
    glutSpecialFunc(clavierSpec);
    glutReshapeFunc(reshape);
    glutMouseFunc(souris);
    glutMotionFunc(sourismouv);

    glutIdleFunc(animAuto); //animation automatique

    glutDisplayFunc(afficher); // Fonction d'affichage
    glutMainLoop(); // Boucle principale GLUT
    return 0;
}

void clavier(unsigned char touche,int x,int y)
{
  switch (touche)
    {
        case 'q' : /*la touche 'q' permet de quitter le programme */
          exit(0);
        case 'p' :
            glutIdleFunc(animTouche);
            break;
    }
    glutPostRedisplay();
}

void clavierSpec(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_LEFT:
            phi -= 0.05f;  // Tourner à gauche autour de l'objet
            break;
        case GLUT_KEY_RIGHT:
            phi += 0.05f;  // Tourner à droite autour de l'objet
            break;
        case GLUT_KEY_UP:
            theta += 0.05;  // Monter la caméra (vers le haut)
            break;
        case GLUT_KEY_DOWN:
            theta -= 0.05;  // Descendre la caméra (vers le bas)
            break;
        default:
            break;
    }

    // Redessiner la scène après un changement
    glutPostRedisplay();
}

void reshape(int x,int y)
{
  if (x<y)
    glViewport(0,(y-x)/2,x,x);
  else
    glViewport((x-y)/2,0,y,y);
}

// Gestion de la souris
void souris(int button, int state,int x,int y)
{
  /* si on appuie sur le bouton gauche */
  if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
  {
    presse = 1; /* le booleen presse passe a 1 (vrai) */
    xold = x; /* on sauvegarde la position de la souris */
    yold=y;
  }
  /* si on relache le bouton gauche */
  if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
    presse=0; /* le booleen presse passe a 0 (faux) */
}

void sourismouv(int x,int y)
  {
    if (presse) /* si le bouton gauche est presse */
    {
      /* on modifie les angles de rotation de l'objet
	 en fonction de la position actuelle de la souris et de la derniere
	 position sauvegardee */
      anglex=anglex+(x-xold);
      angley=angley+(y-yold);
      glutPostRedisplay(); /* on demande un rafraichissement de l'affichage */
    }

    xold=x; /* sauvegarde des valeurs courante de le position de la souris */
    yold=y;
  }



// PARTIE ANIMATION
  void animAuto()
{
    angleQueue += ajoutAuto;
    if (angleQueue>10 || angleQueue <-10)
        ajoutAuto = -ajoutAuto;
    glutPostRedisplay();
}

void animTouche()
{
    angleNageoire += ajoutAutoTouche;
    if (angleNageoire>8 || angleNageoire <-8)
        ajoutAutoTouche = -ajoutAutoTouche;
    glutPostRedisplay();
}


